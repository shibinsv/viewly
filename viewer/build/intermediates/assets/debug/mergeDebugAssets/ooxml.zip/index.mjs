import { t as e } from "./docx-BlELeDNF.js";
import { t } from "./xlsx-dhsUXUpX.js";
import { t as n } from "./pptx-JBkXh6Cy.js";
export { e as docx, n as pptx, t as xlsx };
