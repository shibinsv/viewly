import { t as e } from "./renderer-module-contract-BNGz8HvO.js";
import { n as t } from "./mathjax-DgAl7Yi5.js";
//#region packages/core/assets/mathjax-stix2.js?url
var n = new URL("mathjax-stix2.js", import.meta.url).href, r = null;
function i() {
	return new URL(n, import.meta.url).href;
}
function a(e) {
	return e ? new URL(e, import.meta.url).href : i();
}
function o(e) {
	return new Promise((t, n) => {
		let r = document.createElement("script");
		r.src = e, r.async = !0, r.onload = () => t(), r.onerror = () => n(/* @__PURE__ */ Error(`Failed to load math engine from ${e}`)), document.head.appendChild(r);
	});
}
async function s(e) {
	await import(
		/* @vite-ignore */
		e
);
}
function c(e) {
	return r || (r = (async () => {
		let t = globalThis.__ooxmlStix2;
		if (t) return t;
		let n = a(e);
		typeof document > "u" ? await s(n) : await o(n);
		let r = globalThis.__ooxmlStix2;
		if (!r) throw Error("Math engine failed to initialize");
		return r;
	})(), r);
}
async function l() {
	await c();
}
async function u(e) {
	let n = (await c()).mathml2svg(e);
	return {
		svg: n,
		...t(n)
	};
}
//#endregion
//#region src/math.ts
var d = e({
	loadMathJax: l,
	mathMLToSvg: u
}, "math", { engineAssetUrl: i() });
//#endregion
export { d as math };
